package com.codegym.cms.repository;

import com.codegym.cms.model.Contact;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ContactRepository extends PagingAndSortingRepository<Contact,Integer> {
}
