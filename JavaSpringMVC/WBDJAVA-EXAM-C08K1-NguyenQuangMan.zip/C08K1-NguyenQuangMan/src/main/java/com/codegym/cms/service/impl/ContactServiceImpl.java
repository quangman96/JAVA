package com.codegym.cms.service.impl;

import com.codegym.cms.model.Contact;
import com.codegym.cms.repository.ContactRepository;
import com.codegym.cms.service.ContactService;
import org.springframework.beans.factory.annotation.Autowired;

public class ContactServiceImpl implements ContactService {
    @Autowired
    ContactRepository contactRepository;
    @Override
    public Iterable<Contact> findAll() {
        return contactRepository.findAll();
    }

    @Override
    public Contact findById(int id) {
        return contactRepository.findById(id).get();
    }

    @Override
    public void save(Contact contact) {
        contactRepository.save(contact);
    }

    @Override
    public void remove(int id) {
        contactRepository.deleteById(id);
    }
}
